import mysql.connector as mysql
from phonebook import authentication ,pb_access



#here will perform certain operations 
#and all changes created by user will change our original data as we are connected to our mysql database



print("---------------------------------------Welcome to digital phonebook -----------------------------------------")
print("*** to access phone book user must follow authentication process ***")
authentication()
print("Now you are eligible to access all the operations regarding phonebook ")
pb_access()