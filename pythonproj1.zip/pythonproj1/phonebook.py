import mysql.connector as mysql
import pythonproj1.user_login as user
import pythonproj1.phonebookdetail as details
import pythonproj1.upanddelete as modi

#to access phonebook user must login and if user data is not available then user must sign up first 
def authentication():
    ch1=int(input("1.login\n2.Signup\nEnter your choice here :"))
    if ch1==1:
        user.login()
    elif ch1==2:
        user.signup()

#we are allowing user to perform some opertation using his/her choices

def pb_access():
    print("1. Add contacts\n2. Read all contact\n3. Read any specific contact\n4. Update any specific contact\n5. Delete any specific contact\n6. Delete all contacts")
    ch2 = int(input("Enter your choice here : "))

    if ch2 == 1:
        print("User chose 1. Add Contacts ")
        details.add_contact()
    elif ch2 == 2:
        print("User chose 2. Read all contact ")
        details.readall()
    elif ch2 == 3:
        print("User chose 3.Read any specific contact ")
        details.read_one()
    elif ch2 == 4:
        print("User chose 4. Update any specific contact")
        modi.update()
    elif ch2 == 5:
        print("User chose 5.Delete Any specific contact ")
        modi.delete()
    elif ch2 == 6:
        print("User chose 6. Deete all Data ")
        modi.trunct()
    else :
        print("invalid choice...")




