import mysql.connector as mysql

#user will add data into phone book if he login successfully..
def add_contact():
    mydb=mysql.connect(host="localhost",user="root",password="",database="projpy")
    mycursor = mydb.cursor()
    
    statement = "insert into phonebook values(%s,%s,%s)"
    firstn=input("Enter your First name :").capitalize()
    lastn=input("Enter your Last name: ").capitalize()
    num=input("Enter your Phone number with country code :")

    values=(firstn,lastn,num)
    mycursor.execute(statement,values)
    mydb.commit()
    print("contact get successfully added into your phone book ")

#will use this function to read all the data from database
def readall():
    mydb=mysql.connect(host="localhost",user="root",password="",database="projpy")
    mycursor = mydb.cursor()

    print("Users contact details ..")
    statement = "select * from phonebook"
    mycursor.execute(statement)
    data=mycursor.fetchall()
    for row in data:
        print(row)

#to read any specific data
def read_one():
    mydb=mysql.connect(host="localhost",user="root",password="",database="projpy")
    mycursor = mydb.cursor()

    print("Users contact details ..")
    statement = "select * from phonebook where first_name =%s and last_name=%s"
    firstn=input("Enter your First name :").capitalize()
    lastn=input("Enter your Last name: ").capitalize()
    values=(firstn,lastn)
    mycursor.execute(statement,values)
    data=mycursor.fetchone()
    print(data)

add_contact()