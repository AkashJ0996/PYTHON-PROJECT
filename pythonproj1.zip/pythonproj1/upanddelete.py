import mysql.connector as mysql



mydb=mysql.connect(host="localhost",user="root",password="",database="projpy")
mycursor = mydb.cursor()

#update any specifict contact

def update():
    
    print("update contact details ..")
    choice=int(input("what kind of data you want to update \n 1.First Name\n 2.Last Name\n 3.Phone Num\nEnter your choice here : "))
    if choice == 1 :
        statement = "update phonebook set first_name =%s where first_name=%s"
        firstn_1=input("Enter old First name for updation:").capitalize()
        firstn_2=input("Enter new First name for updation:").capitalize()

        values=(firstn_2,firstn_1)

        mycursor.execute(statement,values)
        

    elif choice == 2 :
        statement = "update phonebook set last_name =%s where last_name=%s"
        lastn_1=input("Enter old Last name for updation: ").capitalize()
        lastn_2=input("Enter new last name fro updation:").capitalize()

        values=(lastn_2,lastn_1)

        mycursor.execute(statement,values)
       

    elif choice == 3:
        statement = "update phonebook set phone_num =%s where first_name=%s and last_name=%s"
        firstn=input("Enter your First name :").capitalize()
        lastn=input("Enter your Last name: ").capitalize()
        phone=input("Enter your new phone number to update the data:")

        values=(phone,firstn,lastn)

        mycursor.execute(statement,values)
        
    else:
        print("invalid choice")
   
    mydb.commit()
    print("updation of data is successfull")
    

#delete any specific contact

def delete():
    
    print("update contact details ..")
   
    statement="delete from phonebook where first_name = %s and last_name = %s "
    firstn=input("Enter your First name :").capitalize()
    lastn=input("Enter your Last name: ").capitalize()

    values = (firstn,lastn)
    mycursor.execute(statement,values)
    
    mydb.commit()
    print("Data got deleted successfully...")

#delete all contacts

def trunct():
    statement="truncate table phonebook"

    mycursor.execute(statement)

    mydb.commit()
    print("All the Data got deleted successfully...")


    
update()






