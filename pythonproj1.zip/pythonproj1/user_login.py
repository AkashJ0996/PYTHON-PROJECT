import mysql.connector as mysql

mydb=mysql.connect(host="localhost",user="root",password="",database="projpy")
mycursor = mydb.cursor()

def signup():
   
    statement = "insert into login_info values(%s,%s)"

    set_user_name = input("Enter your username :")
    set_password = input("Enter your Password :")

    values=(set_user_name ,set_password)

    mycursor.execute(statement,values)

    mydb.commit()
    print("Process of Signup is completed ")


def login():
    user_name = input("Enter your username :")
    password = input("Enter your Password :")

    statement = "SELECT user_name from login_info WHERE user_name=%s AND Password =%s"
    values=(user_name,password)

    mycursor.execute(statement,values)

    if not mycursor.fetchone():
        ch=input("User doesn't exist ...would you like to sign up[y/n]: ")
        if ch=='y' or ch=='Y':
            signup()
        else:
            print("See you later , thanks for visiting our login page")
    else:
        print("login successfully")

login()












